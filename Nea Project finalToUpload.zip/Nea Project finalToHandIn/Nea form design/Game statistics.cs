﻿using Ludo_Class_Lib;
using System;
using System.IO;
using System.Windows.Forms;

namespace Nea_form_design
{
   public partial class Game_statistics : Form
   {
      private string formText;
      /// <summary>
      /// Creates a new instance of the statistics form and creates the string containing the game statistics
      /// </summary>
      /// <param name="game">the game that has been won</param>
      public Game_statistics(Game game)
      {
         InitializeComponent();

         formText = $"Game length: {game.GameLength} (minutes)\r\n";

         foreach (Player player in game.PlayerList)
         {
            formText += $"Player {game.PlayerList.IndexOf(player) + 1} ({player.Colour}):\r\nPlayer name: {player.Name}\r\nPlayer type: {player.PlayerType}\r\nKills: {player.Kills}\r\nMoves made: {player.MovesMade}\r\n";
            if (player == game.WinningPlayer)
            {
               formText += "Winner\r\n";
            }
            formText += "\r\n";
            ;
         }
         GameStatsBox.Text = formText;
      }
      /// <summary>
      /// Lets the user choose the file location and then outputs the statistics to a text file
      /// </summary>
      private void OutputButton_Click(object sender, EventArgs e)
      {
         SaveFileDialog fileSave = new SaveFileDialog();
         if (fileSave.ShowDialog() == DialogResult.OK)
         {
            try
            {
               using (FileStream fs = new FileStream(fileSave.InitialDirectory + fileSave.FileName, FileMode.Create))
               {
                  using (StreamWriter sw = new StreamWriter(fs))
                  {
                     sw.WriteLine(formText);
                     MessageBox.Show("File saved successfully");
                  }
               }
            }
            catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
            }
         }

      }
      /// <summary>
      /// closes the form back to menu
      /// </summary>
      private void QuitButton_Click(object sender, EventArgs e)
      {
         Close();
      }
   }
}
