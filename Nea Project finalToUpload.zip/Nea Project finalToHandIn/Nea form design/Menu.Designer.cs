﻿
namespace Nea_form_design
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
         this.Player1NameBox = new System.Windows.Forms.TextBox();
         this.IsPlayingLabel = new System.Windows.Forms.Label();
         this.NameLabel = new System.Windows.Forms.Label();
         this.IsHumanLabel = new System.Windows.Forms.Label();
         this.Player4NameBox = new System.Windows.Forms.TextBox();
         this.Player3NameBox = new System.Windows.Forms.TextBox();
         this.Player2NameBox = new System.Windows.Forms.TextBox();
         this.Player1IsPlayingCheckbox = new System.Windows.Forms.CheckBox();
         this.Player2IsPlayingCheckbox = new System.Windows.Forms.CheckBox();
         this.Player3IsPlayingCheckbox = new System.Windows.Forms.CheckBox();
         this.Player4IsPlayingCheckbox = new System.Windows.Forms.CheckBox();
         this.player1IsHumanBox = new System.Windows.Forms.ComboBox();
         this.player4IsHumanBox = new System.Windows.Forms.ComboBox();
         this.player3IsHumanBox = new System.Windows.Forms.ComboBox();
         this.player2IsHumanBox = new System.Windows.Forms.ComboBox();
         this.PlayButton = new System.Windows.Forms.Button();
         this.HowToPlayButton = new System.Windows.Forms.Button();
         this.DifficultyLabel = new System.Windows.Forms.Label();
         this.DifficultyBox1 = new System.Windows.Forms.ComboBox();
         this.QuitButton = new System.Windows.Forms.Button();
         this.DifficultyBox4 = new System.Windows.Forms.ComboBox();
         this.DifficultyBox3 = new System.Windows.Forms.ComboBox();
         this.DifficultyBox2 = new System.Windows.Forms.ComboBox();
         this.LoadButton = new System.Windows.Forms.Button();
         this.FileNameBox = new System.Windows.Forms.TextBox();
         this.FileNameLabel = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // Player1NameBox
         // 
         this.Player1NameBox.Location = new System.Drawing.Point(12, 59);
         this.Player1NameBox.Name = "Player1NameBox";
         this.Player1NameBox.Size = new System.Drawing.Size(175, 20);
         this.Player1NameBox.TabIndex = 5;
         this.Player1NameBox.Text = "Player 1";
         // 
         // IsPlayingLabel
         // 
         this.IsPlayingLabel.AutoSize = true;
         this.IsPlayingLabel.Location = new System.Drawing.Point(198, 30);
         this.IsPlayingLabel.Name = "IsPlayingLabel";
         this.IsPlayingLabel.Size = new System.Drawing.Size(51, 13);
         this.IsPlayingLabel.TabIndex = 6;
         this.IsPlayingLabel.Text = "Is playing";
         // 
         // NameLabel
         // 
         this.NameLabel.AutoSize = true;
         this.NameLabel.Location = new System.Drawing.Point(12, 30);
         this.NameLabel.Name = "NameLabel";
         this.NameLabel.Size = new System.Drawing.Size(35, 13);
         this.NameLabel.TabIndex = 7;
         this.NameLabel.Text = "Name";
         // 
         // IsHumanLabel
         // 
         this.IsHumanLabel.AutoSize = true;
         this.IsHumanLabel.Location = new System.Drawing.Point(280, 30);
         this.IsHumanLabel.Name = "IsHumanLabel";
         this.IsHumanLabel.Size = new System.Drawing.Size(64, 13);
         this.IsHumanLabel.TabIndex = 8;
         this.IsHumanLabel.Text = "AI or human";
         // 
         // Player4NameBox
         // 
         this.Player4NameBox.Location = new System.Drawing.Point(12, 179);
         this.Player4NameBox.Name = "Player4NameBox";
         this.Player4NameBox.Size = new System.Drawing.Size(175, 20);
         this.Player4NameBox.TabIndex = 10;
         this.Player4NameBox.Text = "Player 4";
         // 
         // Player3NameBox
         // 
         this.Player3NameBox.Location = new System.Drawing.Point(12, 138);
         this.Player3NameBox.Name = "Player3NameBox";
         this.Player3NameBox.Size = new System.Drawing.Size(175, 20);
         this.Player3NameBox.TabIndex = 11;
         this.Player3NameBox.Text = "Player 3";
         // 
         // Player2NameBox
         // 
         this.Player2NameBox.Location = new System.Drawing.Point(12, 97);
         this.Player2NameBox.Name = "Player2NameBox";
         this.Player2NameBox.Size = new System.Drawing.Size(175, 20);
         this.Player2NameBox.TabIndex = 12;
         this.Player2NameBox.Text = "Player 2";
         // 
         // Player1IsPlayingCheckbox
         // 
         this.Player1IsPlayingCheckbox.AutoSize = true;
         this.Player1IsPlayingCheckbox.Checked = true;
         this.Player1IsPlayingCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
         this.Player1IsPlayingCheckbox.Location = new System.Drawing.Point(201, 62);
         this.Player1IsPlayingCheckbox.Name = "Player1IsPlayingCheckbox";
         this.Player1IsPlayingCheckbox.Size = new System.Drawing.Size(15, 14);
         this.Player1IsPlayingCheckbox.TabIndex = 13;
         this.Player1IsPlayingCheckbox.UseVisualStyleBackColor = true;
         // 
         // Player2IsPlayingCheckbox
         // 
         this.Player2IsPlayingCheckbox.AutoSize = true;
         this.Player2IsPlayingCheckbox.Checked = true;
         this.Player2IsPlayingCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
         this.Player2IsPlayingCheckbox.Location = new System.Drawing.Point(201, 100);
         this.Player2IsPlayingCheckbox.Name = "Player2IsPlayingCheckbox";
         this.Player2IsPlayingCheckbox.Size = new System.Drawing.Size(15, 14);
         this.Player2IsPlayingCheckbox.TabIndex = 14;
         this.Player2IsPlayingCheckbox.UseVisualStyleBackColor = true;
         // 
         // Player3IsPlayingCheckbox
         // 
         this.Player3IsPlayingCheckbox.AutoSize = true;
         this.Player3IsPlayingCheckbox.Checked = true;
         this.Player3IsPlayingCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
         this.Player3IsPlayingCheckbox.Location = new System.Drawing.Point(201, 141);
         this.Player3IsPlayingCheckbox.Name = "Player3IsPlayingCheckbox";
         this.Player3IsPlayingCheckbox.Size = new System.Drawing.Size(15, 14);
         this.Player3IsPlayingCheckbox.TabIndex = 15;
         this.Player3IsPlayingCheckbox.UseVisualStyleBackColor = true;
         // 
         // Player4IsPlayingCheckbox
         // 
         this.Player4IsPlayingCheckbox.AutoSize = true;
         this.Player4IsPlayingCheckbox.Checked = true;
         this.Player4IsPlayingCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
         this.Player4IsPlayingCheckbox.Location = new System.Drawing.Point(201, 182);
         this.Player4IsPlayingCheckbox.Name = "Player4IsPlayingCheckbox";
         this.Player4IsPlayingCheckbox.Size = new System.Drawing.Size(15, 14);
         this.Player4IsPlayingCheckbox.TabIndex = 16;
         this.Player4IsPlayingCheckbox.UseVisualStyleBackColor = true;
         // 
         // player1IsHumanBox
         // 
         this.player1IsHumanBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.player1IsHumanBox.FormattingEnabled = true;
         this.player1IsHumanBox.Location = new System.Drawing.Point(283, 58);
         this.player1IsHumanBox.Name = "player1IsHumanBox";
         this.player1IsHumanBox.Size = new System.Drawing.Size(121, 21);
         this.player1IsHumanBox.TabIndex = 17;
         // 
         // player4IsHumanBox
         // 
         this.player4IsHumanBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.player4IsHumanBox.FormattingEnabled = true;
         this.player4IsHumanBox.Location = new System.Drawing.Point(283, 178);
         this.player4IsHumanBox.Name = "player4IsHumanBox";
         this.player4IsHumanBox.Size = new System.Drawing.Size(121, 21);
         this.player4IsHumanBox.TabIndex = 18;
         // 
         // player3IsHumanBox
         // 
         this.player3IsHumanBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.player3IsHumanBox.FormattingEnabled = true;
         this.player3IsHumanBox.Location = new System.Drawing.Point(283, 137);
         this.player3IsHumanBox.Name = "player3IsHumanBox";
         this.player3IsHumanBox.Size = new System.Drawing.Size(121, 21);
         this.player3IsHumanBox.TabIndex = 19;
         // 
         // player2IsHumanBox
         // 
         this.player2IsHumanBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.player2IsHumanBox.FormattingEnabled = true;
         this.player2IsHumanBox.Location = new System.Drawing.Point(283, 97);
         this.player2IsHumanBox.Name = "player2IsHumanBox";
         this.player2IsHumanBox.Size = new System.Drawing.Size(121, 21);
         this.player2IsHumanBox.TabIndex = 20;
         // 
         // PlayButton
         // 
         this.PlayButton.Location = new System.Drawing.Point(15, 236);
         this.PlayButton.Name = "PlayButton";
         this.PlayButton.Size = new System.Drawing.Size(109, 32);
         this.PlayButton.TabIndex = 21;
         this.PlayButton.Text = "Play";
         this.PlayButton.UseVisualStyleBackColor = true;
         this.PlayButton.Click += new System.EventHandler(this.PlayButtonClick);
         // 
         // HowToPlayButton
         // 
         this.HowToPlayButton.Location = new System.Drawing.Point(245, 236);
         this.HowToPlayButton.Name = "HowToPlayButton";
         this.HowToPlayButton.Size = new System.Drawing.Size(109, 32);
         this.HowToPlayButton.TabIndex = 22;
         this.HowToPlayButton.Text = "How To Play";
         this.HowToPlayButton.UseVisualStyleBackColor = true;
         this.HowToPlayButton.Click += new System.EventHandler(this.HowToPlayButton_Click);
         // 
         // DifficultyLabel
         // 
         this.DifficultyLabel.AutoSize = true;
         this.DifficultyLabel.Location = new System.Drawing.Point(445, 30);
         this.DifficultyLabel.Name = "DifficultyLabel";
         this.DifficultyLabel.Size = new System.Drawing.Size(58, 13);
         this.DifficultyLabel.TabIndex = 24;
         this.DifficultyLabel.Text = "AI difficulty";
         // 
         // DifficultyBox1
         // 
         this.DifficultyBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.DifficultyBox1.FormattingEnabled = true;
         this.DifficultyBox1.Location = new System.Drawing.Point(448, 55);
         this.DifficultyBox1.Name = "DifficultyBox1";
         this.DifficultyBox1.Size = new System.Drawing.Size(121, 21);
         this.DifficultyBox1.TabIndex = 25;
         // 
         // QuitButton
         // 
         this.QuitButton.Location = new System.Drawing.Point(472, 236);
         this.QuitButton.Name = "QuitButton";
         this.QuitButton.Size = new System.Drawing.Size(109, 32);
         this.QuitButton.TabIndex = 26;
         this.QuitButton.Text = "Quit";
         this.QuitButton.UseVisualStyleBackColor = true;
         this.QuitButton.Click += new System.EventHandler(this.QuitButton_Click);
         // 
         // DifficultyBox4
         // 
         this.DifficultyBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.DifficultyBox4.FormattingEnabled = true;
         this.DifficultyBox4.Location = new System.Drawing.Point(448, 178);
         this.DifficultyBox4.Name = "DifficultyBox4";
         this.DifficultyBox4.Size = new System.Drawing.Size(121, 21);
         this.DifficultyBox4.TabIndex = 27;
         // 
         // DifficultyBox3
         // 
         this.DifficultyBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.DifficultyBox3.FormattingEnabled = true;
         this.DifficultyBox3.Location = new System.Drawing.Point(448, 137);
         this.DifficultyBox3.Name = "DifficultyBox3";
         this.DifficultyBox3.Size = new System.Drawing.Size(121, 21);
         this.DifficultyBox3.TabIndex = 28;
         // 
         // DifficultyBox2
         // 
         this.DifficultyBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
         this.DifficultyBox2.FormattingEnabled = true;
         this.DifficultyBox2.Location = new System.Drawing.Point(448, 97);
         this.DifficultyBox2.Name = "DifficultyBox2";
         this.DifficultyBox2.Size = new System.Drawing.Size(121, 21);
         this.DifficultyBox2.TabIndex = 29;
         // 
         // LoadButton
         // 
         this.LoadButton.Location = new System.Drawing.Point(130, 236);
         this.LoadButton.Name = "LoadButton";
         this.LoadButton.Size = new System.Drawing.Size(109, 32);
         this.LoadButton.TabIndex = 30;
         this.LoadButton.Text = "Load a game";
         this.LoadButton.UseVisualStyleBackColor = true;
         this.LoadButton.Click += new System.EventHandler(this.LoadButton_Click);
         // 
         // FileNameBox
         // 
         this.FileNameBox.Location = new System.Drawing.Point(98, 210);
         this.FileNameBox.Name = "FileNameBox";
         this.FileNameBox.Size = new System.Drawing.Size(175, 20);
         this.FileNameBox.TabIndex = 31;
         // 
         // FileNameLabel
         // 
         this.FileNameLabel.AutoSize = true;
         this.FileNameLabel.Location = new System.Drawing.Point(12, 213);
         this.FileNameLabel.Name = "FileNameLabel";
         this.FileNameLabel.Size = new System.Drawing.Size(80, 13);
         this.FileNameLabel.TabIndex = 32;
         this.FileNameLabel.Text = "Game file name";
         // 
         // Menu
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(605, 280);
         this.Controls.Add(this.FileNameLabel);
         this.Controls.Add(this.FileNameBox);
         this.Controls.Add(this.LoadButton);
         this.Controls.Add(this.DifficultyBox2);
         this.Controls.Add(this.DifficultyBox3);
         this.Controls.Add(this.DifficultyBox4);
         this.Controls.Add(this.QuitButton);
         this.Controls.Add(this.DifficultyBox1);
         this.Controls.Add(this.DifficultyLabel);
         this.Controls.Add(this.HowToPlayButton);
         this.Controls.Add(this.PlayButton);
         this.Controls.Add(this.player2IsHumanBox);
         this.Controls.Add(this.player3IsHumanBox);
         this.Controls.Add(this.player4IsHumanBox);
         this.Controls.Add(this.player1IsHumanBox);
         this.Controls.Add(this.Player4IsPlayingCheckbox);
         this.Controls.Add(this.Player3IsPlayingCheckbox);
         this.Controls.Add(this.Player2IsPlayingCheckbox);
         this.Controls.Add(this.Player1IsPlayingCheckbox);
         this.Controls.Add(this.Player2NameBox);
         this.Controls.Add(this.Player3NameBox);
         this.Controls.Add(this.Player4NameBox);
         this.Controls.Add(this.IsHumanLabel);
         this.Controls.Add(this.NameLabel);
         this.Controls.Add(this.IsPlayingLabel);
         this.Controls.Add(this.Player1NameBox);
         this.Name = "Menu";
         this.Text = "Menu";
         this.ResumeLayout(false);
         this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Player1NameBox;
        private System.Windows.Forms.Label IsPlayingLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label IsHumanLabel;
        private System.Windows.Forms.TextBox Player4NameBox;
        private System.Windows.Forms.TextBox Player3NameBox;
        private System.Windows.Forms.TextBox Player2NameBox;
        private System.Windows.Forms.CheckBox Player1IsPlayingCheckbox;
        private System.Windows.Forms.CheckBox Player2IsPlayingCheckbox;
        private System.Windows.Forms.CheckBox Player3IsPlayingCheckbox;
        private System.Windows.Forms.CheckBox Player4IsPlayingCheckbox;
        private System.Windows.Forms.ComboBox player1IsHumanBox;
        private System.Windows.Forms.ComboBox player4IsHumanBox;
        private System.Windows.Forms.ComboBox player3IsHumanBox;
        private System.Windows.Forms.ComboBox player2IsHumanBox;
        private System.Windows.Forms.Button PlayButton;
        private System.Windows.Forms.Button HowToPlayButton;
        private System.Windows.Forms.Label DifficultyLabel;
        private System.Windows.Forms.ComboBox DifficultyBox1;
        private System.Windows.Forms.Button QuitButton;
        private System.Windows.Forms.ComboBox DifficultyBox4;
        private System.Windows.Forms.ComboBox DifficultyBox3;
        private System.Windows.Forms.ComboBox DifficultyBox2;
        private System.Windows.Forms.Button LoadButton;
        private System.Windows.Forms.TextBox FileNameBox;
        private System.Windows.Forms.Label FileNameLabel;
    }
}

