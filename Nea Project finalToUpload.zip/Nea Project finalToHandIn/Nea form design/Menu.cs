﻿using Ludo_Class_Lib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;


namespace Nea_form_design
{

   public partial class Menu : Form
   {
      List<TextBox> playerNameBoxes;
      List<CheckBox> playerCheckBoxes;
      List<Player> playerList;
      /// <summary>
      /// Launches the menu form and populates the options
      /// </summary>
      public Menu()
      {
         InitializeComponent();
         playerList = new List<Player>();
         //populates drop down boxes
         string AiOrHhuman = "Human";
         player1IsHumanBox.Items.Add(AiOrHhuman);
         player2IsHumanBox.Items.Add(AiOrHhuman);
         player3IsHumanBox.Items.Add(AiOrHhuman);
         player4IsHumanBox.Items.Add(AiOrHhuman);
         AiOrHhuman = "AI";
         player1IsHumanBox.Items.Add(AiOrHhuman);
         player2IsHumanBox.Items.Add(AiOrHhuman);
         player3IsHumanBox.Items.Add(AiOrHhuman);
         player4IsHumanBox.Items.Add(AiOrHhuman);
         playerCheckBoxes = new List<CheckBox>();
         playerCheckBoxes.Add(Player1IsPlayingCheckbox);
         playerCheckBoxes.Add(Player2IsPlayingCheckbox);
         playerCheckBoxes.Add(Player3IsPlayingCheckbox);
         playerCheckBoxes.Add(Player4IsPlayingCheckbox);
         playerNameBoxes = new List<TextBox>();
         playerNameBoxes.Add(Player1NameBox);
         playerNameBoxes.Add(Player2NameBox);
         playerNameBoxes.Add(Player3NameBox);
         playerNameBoxes.Add(Player4NameBox);


         List<string> difficulties = new List<string>() { "Easy", "Medium", "Hard" };
         foreach (String difficulty in difficulties)
         {
            DifficultyBox1.Items.Add(difficulty);
            DifficultyBox1.SelectedIndex = 0;
            DifficultyBox2.Items.Add(difficulty);
            DifficultyBox2.SelectedIndex = 0;
            DifficultyBox3.Items.Add(difficulty);
            DifficultyBox3.SelectedIndex = 0;
            DifficultyBox4.Items.Add(difficulty);
            DifficultyBox4.SelectedIndex = 0;
         }
         player1IsHumanBox.SelectedIndex = 0;
         player2IsHumanBox.SelectedIndex = 0;
         player3IsHumanBox.SelectedIndex = 0;
         player4IsHumanBox.SelectedIndex = 0;

      }
      /// <summary>
      /// Launches a new game using the filename
      /// </summary>
      private void PlayButtonClick(object sender, EventArgs e)
      {
         if (CheckIfValidDetails())
         {
            List<Player> playerList = GetPlayersFromForm();
            GameForm newGameForm = new GameForm(playerList, FileNameBox.Text);
            newGameForm.ShowDialog();
         }

      }
      /// <summary>
      /// Checks if the details inputted by the user are valid for a new game
      /// </summary>
      /// <returns>true if details valid, otherwise false</returns>
      private bool CheckIfValidDetails()
      {
         bool isValid = true;
         int boxesChecked = 0;
         foreach (CheckBox checkbox in playerCheckBoxes)
         {
            if (checkbox.Checked)
            {
               boxesChecked++;
            }
         }
         if (boxesChecked > 1)
         {
            foreach (CheckBox checkbox in playerCheckBoxes)
            {
               if (checkbox.Checked)
               {
                  if (playerNameBoxes[playerCheckBoxes.IndexOf(checkbox)].Text == "")
                  {
                     MessageBox.Show($"Error, player {playerCheckBoxes.IndexOf(checkbox) + 1} has no name");
                     isValid = false;
                  }
               }
            }
            if (FileNameBox.Text != "" && isValid) //prevents from creating the file when the previous details were not correct
            {
               try
               {
                  //Checks if filename exists
                  using (FileStream fs = new FileStream($@"{FileNameBox.Text}", FileMode.Open))
                  {

                  }
                  ChooseToUseFileName choiceForm = new ChooseToUseFileName();
                  choiceForm.ShowDialog();
                  isValid = choiceForm.OverWrite;
               }
               catch
               {
                  try
                  {
                     //checks if filename is valid
                     using (FileStream fs = new FileStream($@"{FileNameBox.Text}", FileMode.Create))
                     {

                     }
                  }
                  catch (Exception e)
                  {
                     MessageBox.Show($"file name error: {e.Message}");
                     isValid = false;
                  }
               }
            }
            else if (FileNameBox.Text == "")
            {
               MessageBox.Show("Error, no file name entered");
               isValid = false;
            }

         }
         else
         {
            MessageBox.Show("Error, not enough players");
            isValid = false;
         }
         return isValid;

      }
      /// <summary>
      /// takes the players from the drop down boxes provided the isPlaying checkbox is ticked
      /// </summary>
      /// <returns>generated player list for the new game</returns>
      private List<Player> GetPlayersFromForm()
      {
         playerList.Clear();
         if (Player1IsPlayingCheckbox.Checked)
         {
            CreatePlayer(DifficultyBox1.SelectedIndex, Player1NameBox.Text, player1IsHumanBox.SelectedIndex);
         }
         if (Player2IsPlayingCheckbox.Checked)
         {
            CreatePlayer(DifficultyBox2.SelectedIndex, Player2NameBox.Text, player2IsHumanBox.SelectedIndex);
         }
         if (Player3IsPlayingCheckbox.Checked)
         {
            CreatePlayer(DifficultyBox3.SelectedIndex, Player3NameBox.Text, player3IsHumanBox.SelectedIndex);
         }
         if (Player4IsPlayingCheckbox.Checked)
         {
            CreatePlayer(DifficultyBox4.SelectedIndex, Player4NameBox.Text, player4IsHumanBox.SelectedIndex);
         }
         return playerList;
      }
      /// <summary>
      /// Creates an Ai or human player dependent on isHuman input
      /// </summary>
      /// <param name="difficulty">difficulty of player, zero if human</param>
      /// <param name="name">name of the player</param>
      /// <param name="isHuman">0 if human 1 if computer</param>
      private void CreatePlayer(int difficulty, string name, int isHuman)
      {
         string playerColour = "";
         switch (playerList.Count) //instantiates players in order no matter 
         //which players are ticked in
         {
            case 0:
               playerColour = "Red";
               break;
            case 1:
               playerColour = "Blue";
               break;
            case 2:
               playerColour = "Yellow";
               break;
            case 3:
               playerColour = "Green";
               break;

         }

         if (isHuman == 0)
         {
            Player player = new HumanPlayer(playerColour, name);
            playerList.Add(player);

         }
         else
         {
            ComputerPlayer player = new ComputerPlayer(playerColour, difficulty, name);
            playerList.Add(player);
         }
      }
      /// <summary>
      /// shows message box stating the rules of Ludo
      /// </summary>
      private void HowToPlayButton_Click(object sender, EventArgs e)
      {
         string howToPlayText = "";
         howToPlayText += "Rules of Ludo\r\nLudo is a board game allowing up to four players at once";
         howToPlayText += "\r\nEach player has four pieces which begin in their home poitions" +
         "\r\nEach player then rolls a dice to determine their move." +
         "\r\nTo move one piece out of home a player must roll a six," +
         "\r\nif a player rolls a six they can roll again." +
         "\r\nif a player lands on another enemy piece on a white position," +
         "\r\nthe piece that was landed on is returned to their home area." +
         "\r\nTo win the game a player must get all four of their pieces" +
         "\r\ninto their end arrow.\r\n\r\nThe coloured positions are points of safety.";
         MessageBox.Show(howToPlayText);


      }
      /// <summary>
      /// attempts to load a game from file using the given filename
      /// </summary>
      /// <exception>
      /// Throws exception if file is invalid or error occurs during game launch
      /// </exception>
      private void LoadButton_Click(object sender, EventArgs e)
      {
         string fileName = FileNameBox.Text;
         if (fileName == "")
         {
            MessageBox.Show("Error no filename entered");
         }
         else
         {
            try
            {
               GameForm gameForm = new GameForm(fileName);
               gameForm.ShowDialog();
            }
            catch (Exception exception)
            {
               MessageBox.Show(exception.Message);
            }
         }
      }

      private void QuitButton_Click(object sender, EventArgs e)
      {
         Close();
      }
   }
}
