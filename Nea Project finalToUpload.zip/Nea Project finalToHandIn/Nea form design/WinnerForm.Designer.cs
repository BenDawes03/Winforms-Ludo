﻿
namespace Nea_form_design
{
    partial class WinnerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WinningPlayerLabel = new System.Windows.Forms.Label();
            this.GameStatsButton = new System.Windows.Forms.Button();
            this.QuitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WinningPlayerLabel
            // 
            this.WinningPlayerLabel.AutoSize = true;
            this.WinningPlayerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.WinningPlayerLabel.Location = new System.Drawing.Point(38, 22);
            this.WinningPlayerLabel.Name = "WinningPlayerLabel";
            this.WinningPlayerLabel.Size = new System.Drawing.Size(236, 39);
            this.WinningPlayerLabel.TabIndex = 0;
            this.WinningPlayerLabel.Text = "Player 1 Wins!";
            // 
            // GameStatsButton
            // 
            this.GameStatsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.GameStatsButton.Location = new System.Drawing.Point(12, 74);
            this.GameStatsButton.Name = "GameStatsButton";
            this.GameStatsButton.Size = new System.Drawing.Size(121, 51);
            this.GameStatsButton.TabIndex = 1;
            this.GameStatsButton.Text = "Game Statistics";
            this.GameStatsButton.UseVisualStyleBackColor = true;
            this.GameStatsButton.Click += new System.EventHandler(this.Gamestats_Click);
            // 
            // QuitButton
            // 
            this.QuitButton.Location = new System.Drawing.Point(175, 74);
            this.QuitButton.Name = "QuitButton";
            this.QuitButton.Size = new System.Drawing.Size(121, 51);
            this.QuitButton.TabIndex = 2;
            this.QuitButton.Text = "Quit";
            this.QuitButton.UseVisualStyleBackColor = true;
            this.QuitButton.Click += new System.EventHandler(this.QuitButton_Click);
            // 
            // WinnerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 176);
            this.Controls.Add(this.QuitButton);
            this.Controls.Add(this.GameStatsButton);
            this.Controls.Add(this.WinningPlayerLabel);
            this.Name = "WinnerForm";
            this.Text = "WinnerForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WinningPlayerLabel;
        private System.Windows.Forms.Button GameStatsButton;
        private System.Windows.Forms.Button QuitButton;
    }
}