﻿using System;
using System.Windows.Forms;

namespace Nea_form_design
{
   public partial class ChooseToUseFileName : Form
   {
      private bool overWrite;

      public bool OverWrite

      {
         get { return overWrite; }
         private set { overWrite = value; }
      }
      /// <summary>
      /// Creates a new instance of the ChooseToUseFileName class
      /// </summary>
      public ChooseToUseFileName()
      {
         InitializeComponent();
         overWrite = false;
      }
      /// <summary>
      /// sets the overwrite variable to true and closes
      /// </summary>
      private void YesButton_Click(object sender, EventArgs e)
      {
         overWrite = true;
         Close();
      }
      /// <summary>
      /// sets the overwrite variable to false and closes
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
      private void NoButton_Click(object sender, EventArgs e)
      {
         overWrite = false;
         Close();
      }
   }
}
