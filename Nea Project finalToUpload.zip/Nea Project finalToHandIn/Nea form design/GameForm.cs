﻿using Ludo_Class_Lib;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Nea_form_design
{
   public partial class GameForm : Form
   {
      Game game;

      bool hasMovedPiece;
      int diceRoll;
      const int BUTTONWIDTH = 42;
      const int BUTTONHEIGHT = 42;
      const int REDSTARTBUTTONXPOS = 373;
      const int REDSTARTBUTTONYPOS = 65;
      const int REDTOPHOMEBUTTONXPOS = 526;
      const int REDTOPHOMEBUTTONYPOS = 87;
      const int BLUETOPHOMEBUTTONXPOS = 526;
      const int BLUETOPHOMEBUTTONYPOS = 481;
      const int YELLOWTOPHOMEBUTTONXPOS = 131;
      const int YELLOWTOPHOMEBUTTONYPOS = 482;
      const int GREENTOPHOMEBUTTONXPOS = 131;
      const int GREENTOPHOMEBUTTONYPOS = 87;
      Dictionary<string, Button> playerStartButtons;
      Dictionary<Player, List<Panel>> playerPieceDictionary;
      Dictionary<Button, Node> buttonNodeDictionary;
      Dictionary<Player, List<Button>> homeButtons;
      /// <summary>
      /// Creates a new instnace of the Gameform and creates a new game using the players passed in
      /// </summary>
      /// <param name="playerList">the list of players passed from the menu form</param>
      /// <param name="fileName">the filename to save the game under</param>
      public GameForm(List<Player> playerList, string fileName)
      {
         InitializeComponent();
         homeButtons = new Dictionary<Player, List<Button>>();
         playerStartButtons = new Dictionary<string, Button>();

         game = new Game(playerList, fileName);
         buttonNodeDictionary = new Dictionary<Button, Node>();
         DiceLabel.Text = "Click dice to roll";
         playerLabel.Text = $"{playerList[0].Colour}'s turn";
         hasMovedPiece = true;

         playerPieceDictionary = new Dictionary<Player, List<Panel>>();

         GenerateButtonGrid();
         LoadPiecePanels();
      }
      /// <summary>
      /// Loads the game from a text file
      /// </summary>
      /// <param name="fileName">filename of the save file, file must be in bin folder</param>
      public GameForm(string fileName)
      {
         try
         {
            game = new Game(fileName); //callls the load constructor for the game
         }
         catch (Exception e)
         {
            throw e;
         }
         InitializeComponent();
         homeButtons = new Dictionary<Player, List<Button>>();
         //buttons in the player's home positions
         playerStartButtons = new Dictionary<string, Button>();
         //buttons players start at after leaving home
         buttonNodeDictionary = new Dictionary<Button, Node>();
         DiceLabel.Text = "Click dice to roll";
         playerLabel.Text = $"{game.PlayerList[0].Name}'s turn";
         playerPieceDictionary = new Dictionary<Player, List<Panel>>();
         GenerateButtonGrid();
         LoadPiecePanels();
         MovePiecesToPosition();
         hasMovedPiece = true; //allows player to roll dice     
      }
      /// <summary>
      /// Resets the game board and then move each panel to the position of the piece they represent 
      /// for each player
      /// </summary>
      private void MovePiecesToPosition()
      {
         ResetBoard();
         foreach (Player player in game.PlayerList)
         {
            foreach (Piece piece in player.Pieces)
            {
               if (piece.CurrentNode != player.HomeNode)
               {
                  foreach (Button button in buttonNodeDictionary.Keys)
                  {
                     if (buttonNodeDictionary[button] == piece.CurrentNode)
                     {
                        //move the piece to its equivalent button
                        bool moved = false;
                        foreach (Panel panel in playerPieceDictionary[player])
                        {
                           if (!moved)
                           {
                              foreach (Button homeButton in homeButtons[player])
                              {
                                 if (panel.Controls.Contains(homeButton) && !moved)
                                 {
                                    panel.Controls.Remove(homeButton);
                                    BoardPanel.Controls.Add(homeButton);
                                    homeButton.Location = panel.Location;
                                    if (button.Parent == BoardPanel)
                                    {
                                       panel.Location = button.Location;
                                       panel.Controls.Add(button);
                                       button.Location = new Point(0, 0);
                                       panel.BringToFront();
                                       button.BringToFront();
                                       moved = true;
                                    }
                                    else if (button.Parent == null)
                                    {
                                       throw new Exception("button has no parent");
                                    }
                                    else
                                    {
                                       //button already owned by a piece
                                       panel.Location = button.Parent.Location;
                                       button.Parent.BringToFront();
                                       button.BringToFront();
                                       moved = true;
                                    }

                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
      /// <summary>
      /// Moves every panel that is out of the home back to their home positions
      /// </summary>
      private void ResetBoard()
      {
         foreach (Player player in game.PlayerList)
         {
            foreach (Panel panel in playerPieceDictionary[player])
            {
               bool inHome = false;
               foreach (Button button in homeButtons[player])
               {
                  if (panel.Controls.Contains(button))
                  {
                     inHome = true;
                  }
               }
               if (!inHome)
               {
                  bool found = false;
                  foreach (Button boardButton in buttonNodeDictionary.Keys)
                  {
                     //finds button the piece is on
                     if (panel.Controls.Contains(boardButton))
                     {
                        panel.Controls.Remove(boardButton);
                        BoardPanel.Controls.Add(boardButton);
                        boardButton.Location = panel.Location;
                        boardButton.BringToFront();
                        ReturnPieceToHome(panel);
                        found = true;
                     }
                  }
                  if (!found)
                  {
                     //if piece is behind another piece
                     ReturnPieceToHome(panel);
                  }
               }
            }
            int pieceInHomeCount = 0;
            foreach (Button button in homeButtons[player])
            {
               if (button.Parent != BoardPanel)
               {
                  //button being used by a piece
                  pieceInHomeCount++;
               }
            }
            if (pieceInHomeCount != 4)
            {
               throw new Exception("Not all pieces are in home");
            }
         }
      }
      /// <summary>
      /// Creates the piece panel for each player in the game
      /// </summary>
      private void LoadPiecePanels()
      {
         foreach (Player player in game.PlayerList)
         {
            switch (player.Colour)
            {
               case "Red":
                  AddPiecesToHome(player, REDTOPHOMEBUTTONXPOS, REDTOPHOMEBUTTONYPOS);

                  break;
               case "Yellow":
                  AddPiecesToHome(player, YELLOWTOPHOMEBUTTONXPOS, YELLOWTOPHOMEBUTTONYPOS);
                  break;
               case "Blue":
                  AddPiecesToHome(player, BLUETOPHOMEBUTTONXPOS, BLUETOPHOMEBUTTONYPOS);
                  break;
               case "Green":
                  AddPiecesToHome(player, GREENTOPHOMEBUTTONXPOS, GREENTOPHOMEBUTTONYPOS);
                  break;
            }

         }

      }
      /// <summary>
      /// Adds each of the four buttons to a player's home positions
      /// </summary>
      /// <param name="player">The player who's buttons are being created</param>
      /// <param name="buttonXPos">X position of the top home button on the board panel</param>
      /// <param name="buttonYPos">Y position of the top home button on the board panel</param>
      private void AddPiecesToHome(Player player, int buttonXPos, int buttonYPos)
      {

         List<Button> startButtons = new List<Button>();
         List<Panel> panels = new List<Panel>();
         for (int i = 0; i < 4; i++)
         {
            Panel piecePanel = new Panel();
            piecePanel.Size = new Size(BUTTONWIDTH, BUTTONHEIGHT);
            piecePanel.Top = buttonYPos;
            piecePanel.Left = buttonXPos;
            piecePanel.BackgroundImage = Image.FromFile($@".\{player.Colour}Piece.png");
            piecePanel.BackgroundImageLayout = ImageLayout.Stretch;
            piecePanel.Parent = BoardPanel;
            piecePanel.BackColor = Color.Transparent;
            BoardPanel.Controls.Add(piecePanel);
            piecePanel.BringToFront();
            panels.Add(piecePanel);
            Button button = new Button();
            button.Top = 0;
            button.Left = 0;
            button.Size = new Size(BUTTONWIDTH, BUTTONHEIGHT);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = Color.Transparent;
            button.Click += new EventHandler(pieceButton_Click);
            piecePanel.Controls.Add(button);
            button.BringToFront();

            switch (i)
            {
               case 0:
                  buttonXPos -= BUTTONWIDTH + 2;
                  buttonYPos += BUTTONHEIGHT + 2;

                  break;
               case 1:
                  buttonXPos += 2 * (BUTTONWIDTH + 2);

                  break;
               case 2:


                  buttonXPos -= BUTTONWIDTH + 2;
                  buttonYPos += BUTTONHEIGHT + 2;
                  break;
            }
            startButtons.Add(button);
         }
         homeButtons.Add(player, startButtons);
         playerPieceDictionary.Add(player, panels);
      }

      /// <summary>
      /// Creates the buttons on top of each position on the board and map them to their respective node
      /// in the game. 
      /// </summary>
      private void GenerateButtonGrid()
      {
         int buttonPosX = REDSTARTBUTTONXPOS;
         int buttonPosY = REDSTARTBUTTONYPOS;
         Button button = AddNewButton(buttonPosX, buttonPosY);
         playerStartButtons.Add("Red", button); //easy access to move a piece from home position
         buttonNodeDictionary.Add(button, game.PlayerList[0].StartNode); //maps the button to its node on the graph
         buttonPosY += BUTTONHEIGHT + 2;
         Node node = game.PlayerList[0].StartNode.NextNodes[0];
         for (int i = 0; i < 4; i++) //since the board moves in different directions for different lengths it is difficult to simplify the process
         {
            buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            node = node.NextNodes[0];
            buttonPosY += BUTTONHEIGHT + 2;
         }
         buttonPosX += BUTTONWIDTH + 2;
         for (int i = 0; i < 6; i++)
         {
            buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            node = node.NextNodes[0];
            buttonPosX += BUTTONWIDTH + 2;
         }
         buttonPosX -= BUTTONWIDTH + 2;
         buttonPosY += BUTTONHEIGHT + 2;
         buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
         Node endNode = node.NextNodes[1];
         for (int i = 0; i < 6; i++)
         {
            //Adds end buttons
            int tempButtonPosX = buttonPosX - ((BUTTONWIDTH + 2) * (i + 1));
            buttonNodeDictionary.Add(AddNewButton(tempButtonPosX, buttonPosY), endNode);
            if (i != 5)
            {
               //prevents from exploring past board limits
               endNode = endNode.NextNodes[0];
            }
         }
         buttonPosY += BUTTONHEIGHT + 2;
         node = node.NextNodes[0];
         for (int i = 0; i < 6; i++)
         {
            if (node.Colour != "White" && !node.IsEndNode)
            {
               //adds next start node regardless of a player of that colour existing
               Button startButton = AddNewButton(buttonPosX, buttonPosY);
               playerStartButtons.Add("Blue", startButton);
               buttonNodeDictionary.Add(startButton, node);
            }
            else
            {
               buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            }

            node = node.NextNodes[0];

            buttonPosX -= BUTTONWIDTH + 2;
         }
         buttonPosY += BUTTONHEIGHT + 2;
         for (int i = 0; i < 6; i++)
         {
            buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            node = node.NextNodes[0];

            buttonPosY += BUTTONHEIGHT + 2;
         }
         buttonPosX -= BUTTONWIDTH + 2;
         buttonPosY -= BUTTONHEIGHT + 2;
         buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
         endNode = node.NextNodes[1];
         for (int i = 0; i < 6; i++)
         {
            //Adds end buttons
            int tempButtonPosY = buttonPosY - ((BUTTONHEIGHT + 2) * (i + 1));
            buttonNodeDictionary.Add(AddNewButton(buttonPosX, tempButtonPosY), endNode);
            if (i != 5)
            {
               //prevents from exploring past board limits
               endNode = endNode.NextNodes[0];
            }
         }
         buttonPosX -= BUTTONWIDTH + 2;
         node = node.NextNodes[0];
         for (int i = 0; i < 6; i++)
         {
            if (node.Colour != "White" && !node.IsEndNode)
            {
               //adds next start node regardless of a player of that colour existing
               Button startButton = AddNewButton(buttonPosX, buttonPosY);
               playerStartButtons.Add("Yellow", startButton);
               buttonNodeDictionary.Add(startButton, node);
            }
            else
            {
               buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            }
            node = node.NextNodes[0];

            buttonPosY -= BUTTONHEIGHT + 2;
         }

         buttonPosX -= BUTTONWIDTH + 2;
         for (int i = 0; i < 6; i++)
         {
            buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            node = node.NextNodes[0];

            buttonPosX -= BUTTONWIDTH + 2;
         }
         buttonPosY -= BUTTONHEIGHT + 2;
         buttonPosX += BUTTONWIDTH + 2;
         buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
         endNode = node.NextNodes[1];
         for (int i = 0; i < 6; i++)
         {
            //Adds end buttons
            int tempButtonPosX = buttonPosX + ((BUTTONWIDTH + 2) * (i + 1));
            buttonNodeDictionary.Add(AddNewButton(tempButtonPosX, buttonPosY), endNode);
            if (i != 5)
            {
               //prevents from exploring past board limits
               endNode = endNode.NextNodes[0];
            }
         }
         buttonPosY -= BUTTONHEIGHT + 2;
         node = node.NextNodes[0];
         for (int i = 0; i < 6; i++)
         {
            if (node.Colour != "White" && !node.IsEndNode)
            {
               //adds next start node regardless of a player of that colour existing
               Button startButton = AddNewButton(buttonPosX, buttonPosY);
               playerStartButtons.Add("Green", startButton);
               buttonNodeDictionary.Add(startButton, node);
            }
            else
            {
               buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            }
            node = node.NextNodes[0];

            buttonPosX += BUTTONWIDTH + 2;
         }
         buttonPosY -= BUTTONHEIGHT + 2;
         for (int i = 0; i < 6; i++)
         {

            buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
            node = node.NextNodes[0];
            buttonPosY -= BUTTONHEIGHT + 2;
         }
         buttonPosX += BUTTONWIDTH + 2;
         buttonPosY += BUTTONHEIGHT + 2;
         buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);
         endNode = node.NextNodes[1];
         for (int i = 0; i < 6; i++)
         {
            //Adds end buttons
            int tempButtonPosY = buttonPosY + ((BUTTONHEIGHT + 2) * (i + 1));
            buttonNodeDictionary.Add(AddNewButton(buttonPosX, tempButtonPosY), endNode);
            if (i != 5)
            {
               //prevents from exploring past board limits
               endNode = endNode.NextNodes[0];
            }
         }
         buttonPosX += 44;
         node = node.NextNodes[0];
         buttonNodeDictionary.Add(AddNewButton(buttonPosX, buttonPosY), node);

      }
      /// <summary>
      /// Creates a new button at the indicated position
      /// </summary>
      /// <param name="buttonPosX">X position of the button on the board panel</param>
      /// <param name="buttonPosY">Y position of the button on the board panel</param>
      /// <returns></returns>
      private Button AddNewButton(int buttonPosX, int buttonPosY)
      {
         Button button = new Button();
         button.FlatAppearance.BorderSize = 0;
         button.BackColor = Color.Transparent;
         button.FlatStyle = FlatStyle.Flat;
         button.Left = buttonPosX;
         button.Top = buttonPosY;
         button.Size = new Size(BUTTONWIDTH, BUTTONHEIGHT);
         button.Click += new EventHandler(pieceButton_Click);
         BoardPanel.Controls.Add(button);
         button.BringToFront();
         return button;
      }

      /// <summary>
      /// attempts to find a piece at that button and move it, throws exception if move is invalid or 
      /// there is no piece present
      /// </summary>
      private void pieceButton_Click(object sender, EventArgs e)
      {
         if (game.CurrentPlayer.PlayerType == "Human" && !hasMovedPiece)
         {
            Button button = (Button)sender;
            bool hasMoved = false;
            if (homeButtons[game.CurrentPlayer].Contains(button) && diceRoll == 6)
            {

               //finds corresponding piece
               foreach (Piece piece in game.CurrentPlayer.Pieces) //finds the piece that corresponds to that move
               {
                  if (piece.CurrentNode == game.CurrentPlayer.HomeNode && !hasMoved)
                  {
                     game.PlayTurn(piece);
                     //reloads board to show the new board state
                     MovePiecesToPosition();
                     DiceLabel.Text = "Click to roll dice";
                     hasMoved = true;
                  }
               }
            }
            else
            {
               if (buttonNodeDictionary.Keys.Contains(button))
               {
                  foreach (Piece piece in game.CurrentPlayer.Pieces)
                  {
                     if (piece.CurrentNode == buttonNodeDictionary[button] && !hasMoved)
                     {
                        if (game.PlayTurn(piece)) //moves piece and check if it has won
                        {
                           WinnerForm winnerForm = new WinnerForm(game);
                           winnerForm.ShowDialog();
                           Close();
                        }
                        else
                        {
                           MovePiecesToPosition();
                           DiceLabel.Text = "Click to roll dice";
                           hasMoved = true;
                        }
                     }

                  }
               }

            }
            if (!hasMoved)
            {
               MessageBox.Show("Error, invalid move");
            }
            else
            {
               hasMovedPiece = true;
               playerLabel.Text = $"{game.CurrentPlayer.Colour}'s Turn";
            }
         }
      }
      /// <summary>
      /// Calls the computer make move function for the current diceroll and makes the move
      /// returned
      /// </summary>
      private void PlayComputerTurn()
      {
         Piece pieceToMove = game.CurrentPlayer.MakeMove(game.DiceRoll, game);
         if (game.PlayTurn(pieceToMove)) //moves piece and check if it has won
         {
            WinnerForm winnerForm = new WinnerForm(game);
            winnerForm.ShowDialog();
            Close();
         }
         else
         {
            MovePiecesToPosition();
            hasMovedPiece = true;
            playerLabel.Text = $"{game.CurrentPlayer.Colour}'s Turn";
            DiceLabel.Text = "Click to roll dice";
         }
      }

      /// <summary>
      /// Returns the given panel to an available home button
      /// </summary>
      /// <param name="panel">piece panel to send home</param>
      private void ReturnPieceToHome(Panel panel)
      {
         bool moved = false;
         foreach (Player player in game.PlayerList)
         {
            if (!moved)
            {
               if (playerPieceDictionary[player].Contains(panel))
               {
                  foreach (Button button in homeButtons[player])
                  {
                     bool containsPiece = false;
                     foreach (Panel playerPanel in playerPieceDictionary[player])
                     {
                        if (playerPanel.Controls.Contains(button))
                        {
                           containsPiece = true;
                        }
                     }
                     if (!containsPiece)
                     {
                        panel.Location = button.Location;
                        BoardPanel.Controls.Remove(button);
                        panel.Controls.Add(button);
                        button.Location = new Point(0, 0);
                        moved = true;
                        break;
                     }
                  }
               }
            }
            else
            {
               break; //reduces needless iterations
            }
         }
      }
      /// <summary>
      /// Calls the game.Save function
      /// </summary>
      private void SaveButton_Click(object sender, EventArgs e)
      {
         game.Save();
      }

      /// <summary>
      /// Rolls the dice provided the last diceRoll has been used
      /// displays if a player has been skipped
      /// </summary>
      private void Dice_Click(object sender, EventArgs e)
      {

         if ((hasMovedPiece || game.RollAgain) && !game.DiceRolled)
         {
            string playerColour = game.CurrentPlayer.Colour;
            try
            {
               game.RollDice();
               diceRoll = game.DiceRoll;
               hasMovedPiece = false;

               DiceBox.Image = Image.FromFile($@".\diceFace{diceRoll}.png");
               DiceLabel.Text = "Click on a piece to move it";
               GameInfoLabel.Text = "";
               if (game.CurrentPlayer.PlayerType != "Human")
               {
                  try
                  {
                     PlayComputerTurn();
                  }
                  catch (Exception ex)
                  {
                     throw ex;
                  }
               }

            }
            catch (Exception exc)
            {
               diceRoll = game.DiceRoll;
               DiceBox.Image = Image.FromFile($@".\diceFace{diceRoll}.png");

               if (exc.Message == $"{playerColour} Player cannot move any piece as all pieces are in home and dice roll is not 6")
               {
                  GameInfoLabel.Text = exc.Message;
               }
               else
               {
                  throw exc;
               }
            }
         }
         playerLabel.Text = $"{game.CurrentPlayer.Colour}'s Turn";
      }
      /// <summary>
      /// closes the form
      /// </summary>
      private void QuitClick(object sender, EventArgs e)
      {
         Close();
      }
      /// <summary>
      /// closes the form
      /// </summary>
      private void QuitToolStripMenuItem_Click(object sender, EventArgs e)
      {
         QuitClick(sender, e);
      }
      /// <summary>
      /// Calls the game.Save function
      /// </summary>
      private void saveToolStripMenuItem_Click(object sender, EventArgs e)
      {
         SaveButton_Click(sender, e);
      }
      /// <summary>
      /// Calls rthe Dice_Click function
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>
      private void rollDiceToolStripMenuItem_Click(object sender, EventArgs e)
      {
         Dice_Click(sender, e);
      }
   }
}
