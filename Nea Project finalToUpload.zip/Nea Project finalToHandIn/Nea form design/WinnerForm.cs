﻿using Ludo_Class_Lib;
using System;
using System.Windows.Forms;

namespace Nea_form_design
{
   public partial class WinnerForm : Form
   {
      Game game;
      /// <summary>
      /// Creates a new instance of the Winner form
      /// </summary>
      /// <param name="game">Winning game passed from game form</param>
      public WinnerForm(Game game)
      {
         InitializeComponent();
         WinningPlayerLabel.Text = $"{game.WinningPlayer.Name} wins!";
         this.game = game;
      }
      /// <summary>
      /// launches the statistics form
      /// </summary>
      private void Gamestats_Click(object sender, EventArgs e)
      {
         Game_statistics newstatsForm = new Game_statistics(game);
         newstatsForm.ShowDialog();
         Close();
      }
      /// <summary>
      /// Closes the form
      /// </summary>
      private void QuitButton_Click(object sender, EventArgs e)
      {
         Close();
      }
   }
}
