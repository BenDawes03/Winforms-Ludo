﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ludo_Class_Lib
{
   public abstract class Player
   {
      protected string colour;
      protected List<Piece> pieces;

      protected string name;
      protected string playerType;
      protected Node homeNode;
      private Node startNode;

      public Node StartNode
      {
         get { return startNode; }
         set { startNode = value; }
      }



      public Node HomeNode
      {
         get { return homeNode; }
         private set { homeNode = value; }
      }

      public string PlayerType
      {
         get { return playerType; }
         private set { playerType = value; }
      }



      public string Name
      {
         get { return name; }
         private set { name = value; }
      }
      public List<Piece> Pieces
      {
         get { return pieces; }
         private set { pieces = value; }
      }
      public string Colour
      {
         get { return colour; }
         private set { colour = value; }
      }
      private int movesMade;

      public int MovesMade
      {
         get { return movesMade; }
         private set { movesMade = value; }
      }
      private int kills;

      public int Kills
      {
         get { return kills; }
         set { kills = value; }
      }

      /// <summary>
      /// Creates new instance of the player class
      /// </summary>
      /// <param name="colour">Colour of the player</param>
      /// <param name="name">Name of the player</param>
      /// <param name="playerType">Is the player computer or human</param>
      public Player(string colour, string name, string playerType)
      {
         this.colour = colour;
         this.name = name;
         this.playerType = playerType;
         pieces = new List<Piece>() { new Piece(), new Piece(), new Piece(), new Piece() };
         this.homeNode = new Node(colour, false);
         foreach (Piece piece in pieces)
         {
            piece.CurrentNode = homeNode;
         }

      }
      /// <summary>
      /// Creates a full copy of the player whether loaded from file or copied for the minimax
      /// </summary>
      /// <param name="colour">colour of the player</param>
      /// <param name="name">Name of the player</param>
      /// <param name="playerType">Is the player computer or human</param>
      /// <param name="movesMade">How many moves in total has the player made</param>
      /// <param name="kills">How many times has the player sent an enemy piece back to home</param>
      public Player(string colour, string name, string playerType, int movesMade, int kills)
      {
         this.colour = colour;
         this.name = name;
         this.playerType = playerType;
         pieces = new List<Piece>() { new Piece(), new Piece(), new Piece(), new Piece() };
         homeNode = new Node(colour, false);
         this.movesMade = movesMade;
         this.kills = kills;

      }
      /// <summary>
      /// Used in game load function and moves each piece until it is at its given position
      /// </summary>
      /// <param name="piecePositions">list of integers indicating the distance from start value 
      /// of each piece from file</param>
      public void SetupPiecePositions(List<int> piecePositions)
      {
         for (int i = 0; i < 4; i++)
         {
            if (piecePositions[i] > 0)
            {
               pieces[i].CurrentNode = startNode;
               pieces[i].DistanceFromStart++;
               for (int j = 0; j < piecePositions[i] - 1; j++)
               {
                  if (pieces[i].CurrentNode.NextNodes.Count == 1)
                  {
                     pieces[i].CurrentNode = pieces[i].CurrentNode.NextNodes[0];
                  }
                  else if (pieces[i].CurrentNode.NextNodes.Count == 2)
                  {
                     if (pieces[i].CurrentNode.NextNodes[1].Colour == colour)
                     {
                        pieces[i].CurrentNode = pieces[i].CurrentNode.NextNodes[1];
                     }
                     else
                     {
                        pieces[i].CurrentNode = pieces[i].CurrentNode.NextNodes[0];
                     }
                  }
                  else
                  {
                     throw new Exception("Error, piece is beyond the board parameters");
                  }
                  pieces[i].DistanceFromStart++;
               }
            }
            else
            {
               pieces[i].CurrentNode = homeNode;
            }
         }
      }
      /// <summary>
      /// Moves a piece according to the given diceroll and moves to the start if diceRoll is six and piece is in home 
      /// </summary>
      /// <param name="diceRoll">Current diceRoll of the move</param>
      /// <param name="piece">Piece to move</param>
      public void MakeMove(int diceRoll, Piece piece)
      {
         Node nodeToMoveTo = piece.CurrentNode;
         if (diceRoll == 6 && piece.CurrentNode == homeNode)
         {
            piece.CurrentNode = startNode;
            piece.DistanceFromStart = 1;
            movesMade++;
         }
         else
         {
            for (int i = 0; i < diceRoll; i++)
            {
               if (nodeToMoveTo.NextNodes.Count == 1)
               {
                  nodeToMoveTo = nodeToMoveTo.NextNodes[0];
               }
               else if (nodeToMoveTo.NextNodes.Count == 0 && nodeToMoveTo.IsEndNode)
               {
                  break;
               }
               else
               {
                  if (colour == nodeToMoveTo.NextNodes[1].Colour)
                  {
                     nodeToMoveTo = nodeToMoveTo.NextNodes[1];
                  }
                  else
                  {
                     nodeToMoveTo = nodeToMoveTo.NextNodes[0];
                  }
               }
               piece.DistanceFromStart++;
            }
            piece.CurrentNode = nodeToMoveTo;
            movesMade += diceRoll;
         }

      }
      /// <summary>
      /// function to be inherited by the computer player
      /// </summary>
      /// <param name="diceRoll">current dice roll</param>
      /// <param name="game">copy of the current game</param>
      /// <returns></returns>
      public virtual Piece MakeMove(int diceRoll, Game game)
      {
         return null;
      }
   }

   public class HumanPlayer : Player
   {
      /// <summary>
      /// Creates new instance of the human player class
      /// </summary>
      /// <param name="colour">Colour of the player</param>
      /// <param name="name">Name of the player</param>
      public HumanPlayer(string colour, string name) : base(colour, name, "Human")
      {

      }
      /// <summary>
      /// Creates a full copy of the player whether loaded from file or copied for the minimax
      /// </summary>
      /// <param name="colour">colour of the player</param>
      /// <param name="name">Name of the player</param>
      /// <param name="movesMade">How many moves in total has the player made</param>
      /// <param name="kills">How many times has the player sent an enemy piece back to home</param>
      public HumanPlayer(string colour, string name, int movesMade, int kills) : base(colour, name, "Human", movesMade, kills)
      {


      }



   }

   public class ComputerPlayer : Player
   {
      private int difficulty;

      public int Difficulty
      {
         get { return difficulty; }
         set { difficulty = value; }
      }


      /// <summary>
      /// Creates new instance of the computer player class
      /// </summary>
      /// <param name="colour">Colour of the player</param>
      /// <param name="name">Name of the player</param>
      /// <param name="difficulty">difficulty, 0 - easy, 1 - medium, 2 - hard</param>
      public ComputerPlayer(string colour, int difficulty, string name) : base(colour, name, "Computer")
      {
         this.difficulty = difficulty;

      }
      /// <summary>
      /// Creates a full copy of the player whether loaded from file or copied for the minimax
      /// </summary>
      /// <param name="colour">colour of the player</param>
      /// <param name="name">Name of the player</param>
      /// <param name="difficulty">difficulty, 0 - easy, 1 - medium, 2 - hard</param>
      /// <param name="movesMade">How many moves in total has the player made</param>
      /// <param name="kills">How many times has the player sent an enemy piece back to home</param>
      public ComputerPlayer(string colour, int difficulty, string name, int movesMade, int kills) : base(colour, name, "Computer", movesMade, kills)
      {
         this.difficulty = difficulty;

      }
      /// <summary>
      /// Overrided makemove from player, chooses piece to move for easy difficulty, calls the minimax function 
      /// for each piece for the higher difficulties amnd chooses the highest scoring piece.
      /// </summary>
      /// <param name="diceRoll">current diceroll of the game</param>
      /// <param name="game">deep copy of the current game so the minimax can explore possible moves</param>
      /// <returns>the piece that it chooses to move</returns>
      public override Piece MakeMove(int diceRoll, Game game)
      {

         int maxScore = -9999999;
         Piece maxPiece = new Piece();
         int pieceInEndCount = 0;
         if (difficulty != 0)
         {

            //Medium or hard difficulties
            foreach (Piece p in pieces)
            {

               Game gameToSimulate = game.Clone(); //makes a deep clone of the game so it is not affected by the simulation
               bool pieceFound = false;
               foreach (Player player in gameToSimulate.PlayerList)
               {

                  if (player.Colour == colour)
                  {
                     foreach (Piece piece in player.Pieces) //finds the corresponding piece in the clone game
                     {
                        if (piece.DistanceFromStart == p.DistanceFromStart && !pieceFound)
                        {
                           if (diceRoll == 6 || piece.DistanceFromStart != 0)
                           {
                              int score = MiniMax(5, piece, diceRoll, gameToSimulate, true);
                              int instart = 0;
                              int inEnd = 0;
                              foreach (Piece currentPiece in pieces)
                              {
                                 if (currentPiece.CurrentNode.IsEndNode)
                                 {
                                    inEnd++;
                                 }
                              }

                              if (p.CurrentNode.IsEndNode)
                              {
                                 for (int i = 0; i < 6; i++)
                                 {
                                    score -= 300; //stops the safe piece in the end node from always being the ideal one to move 
                                 }

                              }
                              if (score > maxScore)//is score the highest yet?
                              {
                                 maxPiece = p;
                                 maxScore = score;
                              }
                              pieceFound = true;
                           }

                        }
                     }
                  }
               }
            }
         }
         else
         {
            //easy difficulty
            //finds the furthest piece that is out of the end nodes
            List<Piece> piecesoutOfEnd = new List<Piece>();
            foreach (Piece piece in pieces)
            {
               if (!piece.CurrentNode.IsEndNode)
               {
                  piecesoutOfEnd.Add(piece);
               }

            }
            if (piecesoutOfEnd.Count > 0)
            {
               Piece furthestForwardPiece = piecesoutOfEnd[0];
               foreach (Piece piece in piecesoutOfEnd)
               {
                  if (piece.DistanceFromStart > furthestForwardPiece.DistanceFromStart)
                  {
                     furthestForwardPiece = piece;
                  }
               }
               if (furthestForwardPiece.DistanceFromStart == 0)
               {
                  if (diceRoll == 6)
                  {
                     maxPiece = furthestForwardPiece;

                  }
                  else
                  {
                     foreach (Piece piece in pieces)
                     {
                        if (!piecesoutOfEnd.Contains(piece))
                        {
                           maxPiece = piece;

                        }
                     }
                  }
               }
               else
               {
                  maxPiece = furthestForwardPiece;

               }
            }
            else
            {
               maxPiece = pieces[0];

            }
         }
         foreach (Piece piece in pieces)
         {
            if (piece.CurrentNode.IsEndNode)
            {
               pieceInEndCount++;
            }
         }
         if (pieceInEndCount == 3) //final piece to move into the end receives a huge negative value, this bypasses that.
         {
            foreach (Piece piece in pieces)
            {
               if (!piece.CurrentNode.IsEndNode && piece.CurrentNode != HomeNode)
               {
                  return piece;
               }
            }
         }
         if (pieces.Contains(maxPiece))
         {

            return maxPiece;
         }
         else
         {
            throw new Exception("Error minimax piece output is smaller than minimum piece score");
         }
      }
      /// <summary>
      /// scores the best worst scenario for the next 4 of the player's moves if it moves the given piece and scores it
      /// </summary>
      /// <param name="depth">how many moves the player has made, escape clause exits at zero</param>
      /// <param name="currentPiece">only used at max depth, it is the piece that the function is called to score</param>
      /// <param name="startingRoll">original diceRoll for the piece that the function is scoring</param>
      /// <param name="currentGame">current copy of the game</param>
      /// <param name="isMaximisingPlayer">true if the current player in the game is the function caller, otherwise false, 
      /// determines if the function is "Min" or "Maxing"</param>
      /// <returns>a total score given to the situation the piece was in after each of its five moves</returns>
      private int MiniMax(int depth, Piece currentPiece, int startingRoll, Game currentGame, bool isMaximisingPlayer)
      {

         int score = 0;
         Dictionary<Piece, List<int>> scoreDictionary;

         if (depth == 0) //exit clause
         {
            return score;
         }
         if (isMaximisingPlayer)
         {
            scoreDictionary = currentGame.GetPieceScoresMaximiser(difficulty);
            if (depth == 5)
            {

               currentGame.DiceRoll = startingRoll;
               score += scoreDictionary[currentPiece][startingRoll - 1];
               bool isMaximiser = true;
               if (startingRoll != 6) //player does not cycle for 6
               {
                  currentGame.DiceRolled = true;
                  isMaximiser = false;
               }
               else
               {
                  currentGame.RollAgain = true;
               }

               if (currentGame.PlayTurn(currentPiece)) //if move wins game remaining minimax depth is not needed
               {
                  return score;
               }


               score += MiniMax(depth - 1, currentPiece, startingRoll, currentGame, isMaximiser);

            }
            else
            {
               List<int> maxScorePerPiece = new List<int>();
               foreach (Piece piece in currentGame.CurrentPlayer.Pieces)
               {
                  maxScorePerPiece.Add(scoreDictionary[piece].Max());
               }
               score += maxScorePerPiece.Max();
               Piece pieceToMove = currentGame.CurrentPlayer.Pieces[maxScorePerPiece.IndexOf(maxScorePerPiece.Max())];

               currentGame.DiceRoll = scoreDictionary[pieceToMove].IndexOf(scoreDictionary[pieceToMove].Max()) + 1;
               //sets dice roll to that of the highest scoring move
               bool isMaximiser = true;
               if (currentGame.DiceRoll != 6)
               {
                  currentGame.DiceRolled = true;
                  isMaximiser = false;
                  currentGame.RollAgain = false;
               }
               else
               {
                  currentGame.RollAgain = true;
                  if (pieceToMove.DistanceFromStart == 0)
                  {
                     score -= 30; //negates built up points of moving all pieces from home
                  }

               }

               if (currentGame.PlayTurn(currentGame.CurrentPlayer.Pieces[maxScorePerPiece.IndexOf(maxScorePerPiece.Max())]))
               {
                  return score; //if move wins game remaining minimax depth is not needed
               }

               score += MiniMax(depth - 1, currentPiece, startingRoll, currentGame, isMaximiser);
            }
         }
         else
         {
            scoreDictionary = currentGame.GetPieceScoresMinimiser(colour);

            List<int> minScorePerPiece = new List<int>();

            foreach (Piece piece in currentGame.CurrentPlayer.Pieces)
            {
               minScorePerPiece.Add(scoreDictionary[piece].Min());

            }
            
            score += minScorePerPiece.Min();
            
            Piece pieceToMove = currentGame.CurrentPlayer.Pieces[minScorePerPiece.IndexOf(minScorePerPiece.Min())];


            currentGame.DiceRoll = scoreDictionary[pieceToMove].IndexOf(scoreDictionary[pieceToMove].Min()) + 1;

            currentGame.DiceRolled = true;
            if (currentGame.PlayTurn(pieceToMove))
            {
               return score; //if enemy wins with that move then further depth have no purpose
            }



            if (currentGame.CurrentPlayer.Colour == colour)
            {
               isMaximisingPlayer = true; //checks if the current player is function caller

            }
            score += MiniMax(depth, currentPiece, startingRoll, currentGame, isMaximisingPlayer);

         }
         return score;


      }




   }
}
