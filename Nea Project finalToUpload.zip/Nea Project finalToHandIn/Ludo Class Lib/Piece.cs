﻿namespace Ludo_Class_Lib
{
   public class Piece
   {
      private int distanceFromStart;

      public int DistanceFromStart
      {
         get { return distanceFromStart; }
         set { distanceFromStart = value; }
      }

      public Node CurrentNode { get; set; }
      /// <summary>
      /// Creates new instance of the Piece class
      /// </summary>
      public Piece()
      {
         distanceFromStart = 0;
      }

   }
}
