﻿using System.Collections.Generic;

namespace Ludo_Class_Lib
{
   public class Node
   {

      private bool isEndNode;

      public bool IsEndNode
      {
         get { return isEndNode; }
         private set { isEndNode = value; }
      }


      private List<Node> nextNodes;
      public string Colour { get; private set; }
      public List<Node> NextNodes
      {
         get { return nextNodes; }
         set { nextNodes = value; }
      }

      /// <summary>
      /// creates a new instance of the Node class
      /// </summary>
      /// <param name="colour">the colour of the node, Default white</param>
      /// <param name="isEndNode">is the node part of a player's end arrow</param>
      public Node(string colour, bool isEndNode)
      {
         this.Colour = colour;
         this.isEndNode = isEndNode;
         nextNodes = new List<Node>(0);
      }

   }
}
