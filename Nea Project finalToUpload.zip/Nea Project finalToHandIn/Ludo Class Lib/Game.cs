﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Ludo_Class_Lib
{

   public class Game
   {
      private Stopwatch stopwatch;
      private int gameLength;
      public int GameLength
      {
         get
         {
            return gameLength + stopwatch.Elapsed.Minutes;
         }
         private set { gameLength = value; }
      }
      private bool rollAgain;
      public bool RollAgain
      {
         get { return rollAgain; }
         set { rollAgain = value; }
      }
      private Player winningPlayer;
      public Player WinningPlayer
      {
         get { return winningPlayer; }
         private set { winningPlayer = value; }
      }
      private string fileName;
      public string FileName

      {
         get { return fileName; }
         private set { fileName = value; }
      }
      private Player currentPlayer;

      public List<string> colours = new List<string>() { "Red", "Blue", "Yellow", "Green" };

      private List<Player> playerList;
      private bool diceRolled;
      public bool DiceRolled
      {
         get { return diceRolled; }
         set { diceRolled = value; }
      }
      public List<Player> PlayerList
      {
         get { return playerList; }
         private set { playerList = value; }
      }
      public Player CurrentPlayer
      {
         get { return currentPlayer; }
         private set { currentPlayer = value; }
      }
      private int diceRoll;
      public int DiceRoll
      {
         get { return diceRoll; }
         set { diceRoll = value; }
      }
      /// <summary>
      /// Loads a new game using the filename given
      /// </summary>
      /// <param name="filename">name of game file, must be in bin folder</param>
      public Game(string filename)
      {
         FileStream fs;
         try
         {
            fs = new FileStream($@"{filename}", FileMode.Open);
            fs.Dispose();
         }
         catch
         {
            throw new Exception("Error file not found");
         }
         try
         {
            using (fs = new FileStream($@"{filename}", FileMode.Open))
            {
               StreamReader sr = new StreamReader(fs);
               Dictionary<Player, List<int>> playerToPiecePositionDictionary = new Dictionary<Player, List<int>>();
               gameLength = int.Parse(sr.ReadLine());
               playerList = new List<Player>();

               int playerCount = int.Parse(sr.ReadLine());
               string currentPlayerColour = sr.ReadLine();
               for (int i = 0; i < playerCount; i++) //loads in each player
               {
                  string colour = sr.ReadLine();
                  string name = sr.ReadLine();
                  string playerType = sr.ReadLine();
                  int movesMade = int.Parse(sr.ReadLine());
                  int kills = int.Parse(sr.ReadLine());
                  int difficulty = 0;
                  if (playerType == "Computer") // if it is a computer player the algorithm reads the difficulty value 
                  {
                     difficulty = int.Parse(sr.ReadLine());

                  }
                  List<int> piecePositions = new List<int>();
                  for (int j = 0; j < 4; j++)
                  {
                     piecePositions.Add(int.Parse(sr.ReadLine()));
                  }


                  if (playerType == "Human")
                  {
                     HumanPlayer humanPlayer = new HumanPlayer(colour, name, movesMade, kills);
                     playerToPiecePositionDictionary.Add(humanPlayer, piecePositions);
                     playerList.Add(humanPlayer);
                  }
                  else
                  {
                     ComputerPlayer computerPlayer = new ComputerPlayer(colour, difficulty, name, movesMade, kills);
                     playerToPiecePositionDictionary.Add(computerPlayer, piecePositions);
                     playerList.Add(computerPlayer);
                  }

               }
               foreach (Player player in playerList) //works out the current player
               {
                  if (player.Colour == currentPlayerColour)
                  {
                     currentPlayer = player;
                  }
                  player.StartNode = new Node(player.Colour, false);
               }
               SetupBoard(); //creates graph of nodes that represent board
               foreach (Player player in playerList) //moves the pieces to the position indicated in the file
               {
                  player.SetupPiecePositions(playerToPiecePositionDictionary[player]);
               }
               stopwatch = new Stopwatch(); //restarts game timer
               stopwatch.Start();


            }
         }
         catch
         {
            throw new Exception("Error, the file was in an incorrect format");
         }
      }

      /// <summary>
      /// Creates a new instance of the Game class
      /// </summary>
      public Game(List<Player> playerList, string filename)
      {
         this.playerList = playerList;
         CurrentPlayer = playerList[0];
         foreach (Player player in playerList)
         {
            player.StartNode = new Node(player.Colour, false);
         }
         this.fileName = filename;
         SetupBoard();
         stopwatch = new Stopwatch();
         stopwatch.Start();

      }
      /// <summary>
      /// Saves the game to the file created under the file name
      /// </summary>

      public void Save()
      {
         FileStream fs = new FileStream($@".\{fileName}", FileMode.Truncate);

         StreamWriter sw = new StreamWriter(fs);

         sw.WriteLine(GameLength);
         sw.WriteLine(playerList.Count);
         sw.WriteLine(currentPlayer.Colour);
         foreach (Player player in playerList)
         {
            sw.WriteLine($"{player.Colour}\n{player.Name}\n{player.PlayerType}\n{player.MovesMade}\n{player.Kills}"); //writes player's detaills
            if (player.PlayerType == "Computer")
            {

               sw.WriteLine(((ComputerPlayer)player).Difficulty);
            }
            foreach (Piece piece in player.Pieces)
            {
               sw.WriteLine($"{piece.DistanceFromStart}"); //distance from the player's start position so the game can know where the piece is when reloaded
            }

         }
         sw.Dispose();
      }
      /// <summary>
      /// Clones the game, players and pieces so the minimax can experiment without affecting the real game
      /// </summary>
      /// <returns>deep copy of the current game</returns>
      public Game Clone()
      {
         Dictionary<Player, List<int>> playerPiecePositionDictionary = new Dictionary<Player, List<int>>();
         List<Player> playerListToAdd = new List<Player>();
         foreach (Player player in playerList) //gets each player from the current game
         {
            if (player.PlayerType == "Human")
            {
               HumanPlayer playerToAdd = new HumanPlayer(player.Colour, player.Name); //copies player details
               List<int> piecePositions = new List<int>();
               foreach (Piece piece in player.Pieces)
               {
                  piecePositions.Add(piece.DistanceFromStart); //copies piece positions
               }
               playerPiecePositionDictionary.Add(playerToAdd, piecePositions);
               playerListToAdd.Add(playerToAdd);
            }
            else
            {
               ComputerPlayer playerToAdd = new ComputerPlayer(player.Colour, ((ComputerPlayer)player).Difficulty, player.Name);
               List<int> piecePositions = new List<int>();
               foreach (Piece piece in player.Pieces)
               {
                  piecePositions.Add(piece.DistanceFromStart);
               }
               playerPiecePositionDictionary.Add(playerToAdd, piecePositions);
               playerListToAdd.Add(playerToAdd);
            }

         }
         Game game = new Game(playerListToAdd, fileName);
         foreach (Player duplicatePlayer in game.PlayerList)
         {
            duplicatePlayer.SetupPiecePositions(playerPiecePositionDictionary[duplicatePlayer]); //moves player's pieces from home to the positons they are in the game
            if (duplicatePlayer.Colour == currentPlayer.Colour) // finds the current player
            {
               game.CurrentPlayer = duplicatePlayer;
            }
         }
         game.DiceRoll = diceRoll;
         return game;
      }
      /// <summary>
      /// Rolls the dice 
      /// </summary>
      ///<exception>Throws exception if diceRoll is not six and alll pieces are in home for current player</exception>
      public void RollDice()
      {

         Random randint = new Random();
         diceRoll = randint.Next(1, 7);
         rollAgain = false;
         if (diceRoll == 6)
         {
            diceRolled = true;
            rollAgain = true;
         }
         else
         {
            diceRolled = true;
            int count = 0;
            foreach (Piece piece in CurrentPlayer.Pieces)
            {
               if (piece.CurrentNode == CurrentPlayer.HomeNode)
               {
                  count++;
               }
            }
            if (count == 4)//all pieces in home
            {
               string currentPlayerColour = currentPlayer.Colour;
               currentPlayer = playerList[(playerList.IndexOf(CurrentPlayer) + 1) % playerList.Count];
               diceRolled = false;
               throw new Exception($"{currentPlayerColour} Player cannot move any piece as all pieces are in home and dice roll is not 6");
            }


         }



      }
      /// <summary>
      /// Moves the piece passed to it and checks if a player has won,
      /// if not it will cycle to next player unless previous diceroll is six
      /// </summary>
      /// <param name="piece">chosen piece to move for current turn</param>
      /// <returns>true if a player has won after this move otherwise false</returns>
      public bool PlayTurn(Piece piece)
      {
         bool hasWon = false;
         currentPlayer.MakeMove(diceRoll, piece);
         CheckIfPieceLandedOn(piece);
         if (!CheckIfPlayerWon())
         {
            if (!rollAgain)
            {
               currentPlayer = playerList[(playerList.IndexOf(CurrentPlayer) + 1) % playerList.Count]; //cycles to next player
               diceRolled = false;
            }
            else
            {
               diceRolled = false;
            }
         }
         else
         {
            return true;
         }
         return hasWon;


      }
      /// <summary>
      /// cycles through all players and checks if any have all their pieces in the end nodes
      /// </summary>
      /// <returns>true if a player has won, otherwise false</returns>
      private bool CheckIfPlayerWon()
      {

         foreach (Player player in playerList)
         {
            int count = 0;
            foreach (Piece piece in player.Pieces)
            {
               if (piece.CurrentNode.IsEndNode)
               {
                  count++;
               }
            }
            if (count == 4)//if all four pieces in end nodes
            {
               winningPlayer = player;
               stopwatch.Stop();
               return true;
            }
         }
         return false;
      }
      /// <summary>
      /// Checks if a piece has landed on any enemy players pieces and sends them home if it is a white node
      /// </summary>
      /// <param name="piece">the piece that has just moved</param>
      private void CheckIfPieceLandedOn(Piece piece)
      {
         foreach (Player player in playerList)
         {
            if (player != currentPlayer)
            {
               foreach (Piece enemyPiece in player.Pieces)
               {
                  if (piece.CurrentNode == enemyPiece.CurrentNode && piece.CurrentNode.Colour == "White")
                  {
                     enemyPiece.CurrentNode = player.HomeNode;
                     enemyPiece.DistanceFromStart = 0;
                     currentPlayer.Kills++;
                  }
               }

            }
         }
      }
      /// <summary>
      /// Gets the scores for each move in the minimising mode of the minimax function
      /// </summary>
      /// <param name="targetPlayerColour">colour of the original minimax function caller so all decisions 
      /// are made to their detriment</param>
      /// <returns>A score for each move that the currentb player can make</returns>
      public Dictionary<Piece, List<int>> GetPieceScoresMinimiser(string targetPlayerColour)
      {

         Player targetPlayer = null;
         for (int i = 0; i < PlayerList.Count; i++)//finds the target player in clone game's playerlist
         {
            if (PlayerList[i].Colour == targetPlayerColour)
            {
               targetPlayer = playerList[i];
            }
         }
         Dictionary<Piece, List<int>> scoreDictionary = new Dictionary<Piece, List<int>>();
         List<Node> currentTargetNodes = new List<Node>();
         List<Node> priorityNodes = new List<Node>();
         foreach (Piece piece in targetPlayer.Pieces)
         {
            currentTargetNodes.Add(piece.CurrentNode);
            if (piece.CurrentNode != targetPlayer.HomeNode)
            {
               Node node = piece.CurrentNode;
               for (int i = 0; i < 10; i++) //checks if piece is ten places from the end nodes
               {
                  if (node.NextNodes.Count > 1)
                  {
                     if (node.NextNodes[1].Colour == targetPlayer.Colour)
                     {
                        priorityNodes.Add(piece.CurrentNode);
                        break;
                     }
                  }
               }
            }
         }



         foreach (Piece piece in currentPlayer.Pieces)
         {
            int[] scores = new int[6];
            if (piece.CurrentNode != currentPlayer.HomeNode)
            {
               if (piece.CurrentNode.NextNodes.Count > 0)
               {
                  Node nextNode = piece.CurrentNode.NextNodes[0];
                  bool inRange = false;
                  for (int i = 0; i < 6; i++)
                  {
                     if (currentTargetNodes.Contains(nextNode))
                     {
                        scores[i] -= 20;
                        if (priorityNodes.Contains(nextNode))
                        {
                           scores[i] -= 50;
                        }
                     }
                     if (!inRange)
                     {

                        Node tempNode = nextNode;
                        //checks if there are any pieces belonging to the target in range of the move
                        for (int j = 0; j < 6; j++)
                        {

                           if (currentTargetNodes.Contains(tempNode) && !inRange)
                           {
                              scores[i] -= 10;
                              inRange = true;
                           }
                           else
                           {
                              if (tempNode.NextNodes.Count > 0)
                              {
                                 tempNode = tempNode.NextNodes[0];
                              }
                              else
                              {
                                 break;
                              }
                           }
                        }
                     }

                     else //all moves after the one that is in range get the ten points as well
                     {
                        scores[i] -= 10;
                     }
                     if (nextNode.NextNodes.Count > 0)
                     {
                        if (nextNode.NextNodes.Count == 2)
                        {
                           if (currentPlayer.Colour == nextNode.NextNodes[1].Colour)
                           {
                              int inEnd = 0;
                              foreach (Piece currentPiece in currentPlayer.Pieces)
                              {
                                 if (currentPiece.CurrentNode.IsEndNode)
                                 {
                                    inEnd++;
                                 }
                              }
                              if (inEnd == 3 && i < 5) //move allows player to win 
                              {
                                 for (int j = i + 1; j < 6; j++)
                                 {
                                    scores[j] -= 999;
                                 }
                              }
                           }
                        }
                        else
                        {
                           nextNode = nextNode.NextNodes[0];
                        }
                     }

                     else
                     {
                        break;
                     }
                  }
               }
            }
            else
            {
               scores[5] -= 1; //moving a piece from home gives -1 point
            }
            scoreDictionary.Add(piece, scores.ToList());
         }
         return scoreDictionary;

      }
      /// <summary>
      /// Calculates scores for each move that a player can make for the original function caller of the 
      /// minimax algorithm
      /// </summary>
      /// <param name="difficulty">difficulty of the player who called the function</param>
      /// <returns>A score for each move that the currentb player can make</returns>
      public Dictionary<Piece, List<int>> GetPieceScoresMaximiser(int difficulty)
      {
         Dictionary<Piece, List<int>> scoreDictionary = new Dictionary<Piece, List<int>>();
         List<Node> DangerNodes = new List<Node>(); //places where you are in range of an enemy piece
         List<Node> CurrentEnemyNodes = new List<Node>();
         List<Node> priorityNodes = new List<Node>(); //places that are ten from their end nodes

         foreach (Player player in playerList) //maps all enemy positions
         {
            if (player != currentPlayer)
            {
               foreach (Piece piece in player.Pieces)
               {
                  Node currentNode = piece.CurrentNode;



                  CurrentEnemyNodes.Add(currentNode);
                  if (currentNode != player.HomeNode)
                  {

                     for (int i = 1; i <= 6; i++)
                     {
                        if (currentNode.NextNodes.Count > 0)
                        {
                           currentNode = currentNode.NextNodes[0];
                           if (currentNode.Colour == "White")
                           {
                              DangerNodes.Add(currentNode);

                           }

                        }


                     }
                     //priority node scoring
                     Node node = piece.CurrentNode;
                     for (int i = 0; i < 10; i++)
                     {
                        if (node.NextNodes.Count > 1)
                        {
                           if (node.NextNodes[1].Colour == player.Colour)
                           {
                              priorityNodes.Add(piece.CurrentNode);
                              break;
                           }
                        }
                        else if (node.NextNodes.Count == 1)
                        {

                           node = node.NextNodes[0];
                        }
                     }
                  }
               }
            }
         }

         foreach (Piece piece in currentPlayer.Pieces)
         {
            int[] scores = new int[6];
            int homeCount = 0;
            foreach (Piece playerpiece in currentPlayer.Pieces)
            {
               if (playerpiece.CurrentNode == currentPlayer.HomeNode)
               {
                  homeCount++;
               }
            }
            if (piece.CurrentNode == currentPlayer.HomeNode)
            {
               if (homeCount == 4)
               {
                  scores[5] += 30;
                  //score of 30 points given to releasing piece from home regardless of position
               }
               for (int i = 0; i < 6; i++)
               {
                  if (i != 5)
                  {
                     scores[i] -= 99999;
                  }
               }

            }
            else if (piece.CurrentNode.IsEndNode)
            {
               for (int i = 0; i < 6; i++)
               {
                  scores[i] -= 10;
                  //stops the safe piece in the end node from always being the ideal one to move 
               }

            }
            else
            {




               List<Node> PossibleMoves = new List<Node>();

               Node currentNode = piece.CurrentNode;
               for (int i = 1; i <= 6; i++)
               {
                  if (currentNode.NextNodes.Count > 1)
                  {
                     if (currentNode.NextNodes[1].Colour == currentPlayer.Colour)
                     {
                        currentNode = currentNode.NextNodes[1];
                     }
                     else
                     {
                        currentNode = currentNode.NextNodes[0];
                     }
                  }
                  else
                  {
                     currentNode = currentNode.NextNodes[0];
                  }
                  PossibleMoves.Add(currentNode);
               }
               currentNode = piece.CurrentNode;

               if (DangerNodes.Contains(currentNode))
               {
                  bool canEscape = false;

                  int escapeRoll = 0;

                  foreach (Node node in PossibleMoves)
                  {
                     if (!DangerNodes.Contains(node))
                     {
                        canEscape = true;
                        break;
                     }
                     else
                     {
                        scores[escapeRoll] += 5;
                        escapeRoll++;

                     }
                  }

                  if (canEscape)
                  {

                     for (int i = escapeRoll; i < 6; i++)
                     // moves does not put piece in danger so add 2 to the 40 points gained for escaping
                     {
                        scores[i] += 42;
                     }

                  }

                  currentNode = piece.CurrentNode;

               }

               else
               {

                  foreach (Node node in PossibleMoves)
                  {
                     if (DangerNodes.Contains(node))
                     {
                        scores[PossibleMoves.IndexOf(node)] -= 20; //move puts player in range of enemy piece
                     }
                     else
                     {
                        scores[PossibleMoves.IndexOf(node)] += 2; //adds 2 for a safe move
                     }
                  }

               }
               foreach (Node node in PossibleMoves)
               {
                  if (CurrentEnemyNodes.Contains(node) && difficulty == 2 && node.Colour == "White")
                  {
                     scores[PossibleMoves.IndexOf(node)] += 25;//land on enemy piece
                     if (priorityNodes.Contains(node))
                     {
                        scores[PossibleMoves.IndexOf(node)] += 70; //piece is ten from end position
                     }
                  }
                  if (node.Colour != "White")
                  {
                     scores[PossibleMoves.IndexOf(node)] += 10;
                  }
                  if (node.IsEndNode && !piece.CurrentNode.IsEndNode)
                  {
                     int inEnd = 0;
                     foreach (Piece currentPiece in currentPlayer.Pieces)
                     {
                        if (currentPiece.CurrentNode.IsEndNode)
                        {
                           inEnd++;
                        }
                     }
                     if (inEnd == 3) //move allows player to win 
                     {
                        for (int j = PossibleMoves.IndexOf(node); j < 6; j++)
                        {
                           scores[j] += 99900;
                        }
                     }
                     else
                     {
                        scores[PossibleMoves.IndexOf(node)] += 35;
                     }
                  }

               }

               for (int i = 0; i < 12; i++)
               {

                  if (CurrentEnemyNodes.Contains(currentNode) && currentNode.Colour == "White" && difficulty == 2)
                  {
                     if (i <= 5)
                     {
                        for (int j = i; j < 6; j++) //move puts piece in range to attack enemy piece
                        {
                           scores[j] += 10;
                        }

                     }
                     else
                     {
                        for (int j = i - 5; j < 6; j++)
                        // counts all possible moves onward from the move that puts it in range and adds ten if it is on hard
                        {
                           scores[j] += 10;
                        }

                     }
                     break;
                  }
                  currentNode = currentNode.NextNodes[0];

               }
            }
            scoreDictionary.Add(piece, scores.ToList());
         }

         return scoreDictionary;
      }


      /// <summary>
      /// creates the graph that represents the game board
      /// </summary>
      public void SetupBoard()
      {
         List<string> colours = new List<string>() { "Blue", "Yellow", "Green", "Red" };
         //these determine the order of the player start positions and the end arrows

         Node StartNode = playerList[0].StartNode;
         Node newStartNode = StartNode;
         for (int i = 0; i < 4; i++) //must cycle for four times regardless of the player count
         {

            Node nextNode = new Node("White", false);
            newStartNode.NextNodes.Add(nextNode);
            for (int j = 0; j < 10; j++)
            {
               Node newNode = new Node("White", false);
               nextNode.NextNodes.Add(newNode);
               nextNode = newNode;
            }
            nextNode.NextNodes.Add(new Node("White", false));
            Node endNode = new Node(colours[i], true);
            nextNode.NextNodes.Add(endNode);
            for (int k = 0; k < 5; k++)
            {
               endNode.NextNodes.Add(new Node(colours[i], true));
               if (k != 4)
               {
                  endNode = endNode.NextNodes[0];
               }
            }
            nextNode = nextNode.NextNodes[0];
            if (i + 1 < playerList.Count)
            {
               newStartNode = playerList[(i + 1) % playerList.Count].StartNode;
            }
            else if (i < 3)//used if there are less than 4 players 
            {
               newStartNode = new Node(colours[i], false);
            }
            else
            {
               newStartNode = playerList[0].StartNode;
            }
            nextNode.NextNodes.Add(newStartNode);

         }

      }
   }
}
